<?php
      $db_server = "localhost";
      $db_user = "root";
      $db_pass = "";
      $db_name = "customoshop(1)";
      $db_conn = "";

      $conn = mysqli_connect($db_server, $db_user, $db_pass, $db_name);

?>